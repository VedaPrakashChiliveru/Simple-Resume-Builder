<?php
$u_name=$_REQUEST["name"];
$u_email=$_REQUEST["email"];
$u_ph=$_REQUEST["phone"];
$u_password=$_REQUEST["pass"];


$servername ="localhost";
$username="root";
$password="";
$dbname = "client";

$conn = mysqli_connect($servername,$username,$password,$dbname );
if($conn->connect_error){
  die("connection failed:".$conn->connect_error);
}
$sql="INSERT INTO record (c_name,c_email,c_phone,c_password) values('$u_name','$u_email','$u_ph','$u_password')";

if(mysqli_query($conn,$sql)){
  echo "records added successfully";
  echo " <a href='loginpage.html' >click here to login </a>";

}
else {
  echo "insertion failed".$conn->connect_error;
}
mysqli_close($conn);
 ?>
