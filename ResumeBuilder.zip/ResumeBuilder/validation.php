<?php

$l_un



$u_name=$_POST["name"];
$u_email=$_POST["email"];
$u_ph=$_POST["phone"];
$u_password=$_POST["pass"];
echo $u_name;
echo $u_email;
echo $u_ph;
echo $u_password;

 ?>
