
<?php



function SignIn()
{
$con = new mysqli('localhost','root','','client');
$name = $_POST['name'];
$pass = $_POST['Password'];
$sql = "SELECT * FROM record where c_name ='$name'  AND c_password = '$pass'";
$result = $con->query($sql);
if ($result->num_rows > 0)
{
echo "SUCCESSFULLY LOGIN TO USER PROFILE PAGE...";

header("location:homepage.html");
}
else
{
echo "SORRY... YOU ENTERD WRONG ID AND PASSWORD... PLEASE RETRY...";
echo "click here to login again<a href='loginpage.html'>click here</a>";
}
}
if(isset($_POST['login']))
{
SignIn();
}

 ?>
